# CSC 365 Lab 5 - Aggregations

## Author: Andrew Cheung
## Email: acheun29@calpoly.edu
